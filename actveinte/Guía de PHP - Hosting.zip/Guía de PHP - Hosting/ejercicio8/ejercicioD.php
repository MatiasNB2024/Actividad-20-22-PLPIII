<?php
echo "Incremento de 2 en 2:<br>";
for ($f = 2; $f <= 20; $f += 2) {
    echo $f . "<br>";
}
?>
