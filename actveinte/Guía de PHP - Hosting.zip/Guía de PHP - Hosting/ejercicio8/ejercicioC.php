<?php
echo "Tabla del 2 usando do/while:<br>";
$i = 1;
do {
    echo "2 x $i = " . (2 * $i) . "<br>";
    $i++;
} while ($i <= 10);
?>
