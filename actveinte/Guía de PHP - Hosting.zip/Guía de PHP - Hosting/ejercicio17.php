<?php
$clavesUsuarios = [
    "usuario1" => "clave123",
    "usuario2" => "abc456",
    "usuario3" => "pass789",
    "usuario4" => "clave321",
    "usuario5" => "xyz987"
];

// Accedemos a una clave específica, por ejemplo, la de usuario3
echo "Clave de usuario3: " . $clavesUsuarios["usuario3"];
?>
