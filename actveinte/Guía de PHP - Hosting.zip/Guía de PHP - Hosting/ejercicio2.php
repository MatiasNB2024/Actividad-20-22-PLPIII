<?php
$entero = 10;        // Tipo integer
$doble = 3.14;       // Tipo double
$cadena = "Hola";    // Tipo string
$booleano = true;    // Tipo boolean

echo "Entero: $entero<br>";
echo "Double: $doble<br>";
echo "String: $cadena<br>";
echo "Booleano: " . ($booleano ? 'true' : 'false') . "<br>";
?>
