<?php
$entero = 42;          // Tipo integer
$decimal = 3.14;       // Tipo double
$cadena = "Hola Mundo"; // Tipo string
$booleano = true;      // Tipo boolean

echo "Entero: $entero<br>";
echo "Double: $decimal<br>";
echo "String: $cadena<br>";
echo "Booleano: " . ($booleano ? 'true' : 'false') . "<br>";
?>
