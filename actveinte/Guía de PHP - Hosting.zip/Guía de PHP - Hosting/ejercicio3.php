<?php
$num1 = 5;
$num2 = 10;
$num3 = 15;

$mensaje = "Los números son $num1, $num2 y $num3.";
echo $mensaje;
?>
