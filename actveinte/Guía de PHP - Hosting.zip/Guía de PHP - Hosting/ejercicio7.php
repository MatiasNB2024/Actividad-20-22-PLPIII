<?php
$valor = rand(1, 3);

if ($valor == 1) {
    echo "uno";
} elseif ($valor == 2) {
    echo "dos";
} elseif ($valor == 3) {
    echo "tres";
}
?>
