<?php
$diasSemana = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

echo "Primer día de la semana: " . $diasSemana[0] . "<br>";
echo "Último día de la semana: " . end($diasSemana);
?>